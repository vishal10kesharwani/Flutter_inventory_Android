import 'package:flutter/cupertino.dart';

class ManualAddScreen extends StatefulWidget {
  const ManualAddScreen({Key? key}) : super(key: key);

  @override
  State<ManualAddScreen> createState() => _ManualAddScreenState();
}

class _ManualAddScreenState extends State<ManualAddScreen> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
